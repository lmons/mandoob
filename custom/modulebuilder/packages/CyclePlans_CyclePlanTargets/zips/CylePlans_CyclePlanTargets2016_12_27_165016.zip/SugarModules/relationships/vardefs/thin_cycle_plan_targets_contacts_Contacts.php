<?php
// created: 2016-12-27 16:50:16
$dictionary["Contact"]["fields"]["thin_cycle_plan_targets_contacts"] = array (
  'name' => 'thin_cycle_plan_targets_contacts',
  'type' => 'link',
  'relationship' => 'thin_cycle_plan_targets_contacts',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlanTargets',
  'bean_name' => false,
  'vname' => 'LBL_THIN_CYCLE_PLAN_TARGETS_CONTACTS_FROM_THIN_CYCLEPLANTARGETS_TITLE',
);
