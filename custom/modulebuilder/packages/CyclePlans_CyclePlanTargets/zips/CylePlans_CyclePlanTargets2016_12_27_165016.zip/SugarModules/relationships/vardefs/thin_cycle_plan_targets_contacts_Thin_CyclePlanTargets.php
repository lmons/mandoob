<?php
// created: 2016-12-27 16:50:16
$dictionary["Thin_CyclePlanTargets"]["fields"]["thin_cycle_plan_targets_contacts"] = array (
  'name' => 'thin_cycle_plan_targets_contacts',
  'type' => 'link',
  'relationship' => 'thin_cycle_plan_targets_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_THIN_CYCLE_PLAN_TARGETS_CONTACTS_FROM_CONTACTS_TITLE',
);
