<?php
 // created: 2017-02-17 13:14:51
$dictionary['Contact']['fields']['address_c']['inline_edit']='1';
$dictionary['Contact']['fields']['address_c']['labelValue']='Address';

 ?>