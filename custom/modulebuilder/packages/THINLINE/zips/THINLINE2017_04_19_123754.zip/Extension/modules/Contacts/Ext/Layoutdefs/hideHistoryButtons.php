<?php
$layout_defs["Contacts"]["subpanel_setup"]['history']['top_buttons'] = array(
  /*  array('widget_class' => 'SubPanelTopCreateNoteButton'),
    array('widget_class' => 'SubPanelTopArchiveEmailButton'),
    array('widget_class' => 'SubPanelTopSummaryButton'),*/
    array('widget_class' => 'SubPanelTopFilterButton'),

);