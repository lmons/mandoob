<?php
 // created: 2017-01-25 18:49:17
$dictionary['Call']['fields']['call_location_name_c']['inline_edit']='1';
$dictionary['Call']['fields']['call_location_name_c']['labelValue']='Call Location';

 ?>