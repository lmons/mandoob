<?php
 // created: 2016-12-29 18:18:07
$dictionary['Account']['fields']['brick_c']['inline_edit']='1';
$dictionary['Account']['fields']['brick_c']['labelValue']='Brick';

 ?>