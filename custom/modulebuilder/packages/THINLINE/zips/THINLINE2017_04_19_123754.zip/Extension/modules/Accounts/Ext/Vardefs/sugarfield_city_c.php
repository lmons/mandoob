<?php
 // created: 2016-12-30 13:01:08
$dictionary['Account']['fields']['city_c']['inline_edit']='1';
$dictionary['Account']['fields']['city_c']['labelValue']='City';

 ?>