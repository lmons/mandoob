<?php
// created: 2017-02-20 15:08:30
$dictionary["Call"]["fields"]["calls_aos_products_1"] = array (
  'name' => 'calls_aos_products_1',
  'type' => 'link',
  'relationship' => 'calls_aos_products_1',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'vname' => 'LBL_CALLS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE',
);
