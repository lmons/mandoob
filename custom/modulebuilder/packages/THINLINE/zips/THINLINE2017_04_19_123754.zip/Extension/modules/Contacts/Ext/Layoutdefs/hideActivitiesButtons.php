<?php
$layout_defs["Contacts"]["subpanel_setup"]['activities']['top_buttons'] = array(
  /*  array('widget_class' => 'SubPanelTopCreateTaskButton'),
    array('widget_class' => 'SubPanelTopScheduleMeetingButton'),
    array('widget_class' => 'SubPanelTopComposeEmailButton'),*/
    array('widget_class' => 'SubPanelTopScheduleCallButton'),

);