<?php 
 // created: 2017-04-19 12:37:44
$mod_strings['LBL_TM_TYPE'] = 'Type';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';

?>
