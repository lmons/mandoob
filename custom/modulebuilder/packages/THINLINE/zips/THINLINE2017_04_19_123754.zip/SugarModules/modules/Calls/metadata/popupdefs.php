<?php
$popupMeta = 
array (
  'moduleMain' => 'Calls',
  'varName' => 'Call',
  'orderBy' => 'calls.name',
  'whereClauses' => 
  array (
    'name' => 'calls.name',
  ),
  'searchInputs' => 
  array (
    0 => 'calls_number',
    1 => 'name',
    2 => 'priority',
    3 => 'status',
  ),
);
?>
