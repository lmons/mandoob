<?php
class ListViewLogicHook {

    public function getDurationListValue($bean, $event, $arguments) {
        $bean->duration=$bean->duration_hours." h";
    }
}