<?php 
 // created: 2017-04-19 12:36:18
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_BRICK'] = 'Brick';
$mod_strings['LBL_COUNTRY'] = 'Country';
$mod_strings['LBL_CITY'] = 'City';

?>
