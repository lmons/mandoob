<?php 
$app_list_strings['product_type_dom'] = array (
  'Detail' => 'Detail',
  'Sample' => 'Sample',
);$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Clinic' => 'Clinic',
  'Hospital' => 'Hospital',
  'Pharmacy' => 'Pharmacy',
);$app_list_strings['thin_country_list'] = array (
  'algeria' => 'Algeria',
  'Morocco' => 'Morocco',
  'Tunisia' => 'Tunisia',
);