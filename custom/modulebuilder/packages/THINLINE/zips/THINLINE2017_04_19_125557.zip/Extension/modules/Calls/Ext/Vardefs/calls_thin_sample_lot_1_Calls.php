<?php
// created: 2017-03-10 19:21:24
$dictionary["Call"]["fields"]["calls_thin_sample_lot_1"] = array (
  'name' => 'calls_thin_sample_lot_1',
  'type' => 'link',
  'relationship' => 'calls_thin_sample_lot_1',
  'source' => 'non-db',
  'module' => 'Thin_Sample_Lot',
  'bean_name' => 'Thin_Sample_Lot',
  'side' => 'right',
  'vname' => 'LBL_CALLS_THIN_SAMPLE_LOT_1_FROM_THIN_SAMPLE_LOT_TITLE',
);
