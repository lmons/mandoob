<?php
// created: 2017-01-04 15:11:31
$dictionary["Terri_Territoire"]["fields"]["terri_territoire_thin_cycleplans_1"] = array (
  'name' => 'terri_territoire_thin_cycleplans_1',
  'type' => 'link',
  'relationship' => 'terri_territoire_thin_cycleplans_1',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlans',
  'bean_name' => 'Thin_CyclePlans',
  'side' => 'right',
  'vname' => 'LBL_TERRI_TERRITOIRE_THIN_CYCLEPLANS_1_FROM_THIN_CYCLEPLANS_TITLE',
);
