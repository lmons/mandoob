<?php
 // created: 2017-01-04 15:11:31
$layout_defs["Terri_Territoire"]["subpanel_setup"]['terri_territoire_thin_cycleplans_1'] = array (
  'order' => 100,
  'module' => 'Thin_CyclePlans',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TERRI_TERRITOIRE_THIN_CYCLEPLANS_1_FROM_THIN_CYCLEPLANS_TITLE',
  'get_subpanel_data' => 'terri_territoire_thin_cycleplans_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
