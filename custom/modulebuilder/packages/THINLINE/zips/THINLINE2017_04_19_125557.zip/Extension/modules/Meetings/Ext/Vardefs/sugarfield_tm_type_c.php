<?php
 // created: 2017-03-24 19:27:49
$dictionary['Meeting']['fields']['tm_type_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['tm_type_c']['labelValue']='Type';

 ?>