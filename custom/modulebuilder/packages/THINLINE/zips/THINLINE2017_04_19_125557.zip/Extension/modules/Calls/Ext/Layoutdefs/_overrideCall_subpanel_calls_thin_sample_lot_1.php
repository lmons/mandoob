<?php
//auto-generated file DO NOT EDIT
$layout_defs['Calls']['subpanel_setup']['calls_thin_sample_lot_1']['override_subpanel_name'] = 'Call_subpanel_calls_thin_sample_lot_1';
?>