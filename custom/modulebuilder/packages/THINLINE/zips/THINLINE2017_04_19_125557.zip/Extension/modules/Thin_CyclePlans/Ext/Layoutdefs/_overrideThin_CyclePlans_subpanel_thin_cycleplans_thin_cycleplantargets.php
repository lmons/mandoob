<?php
//auto-generated file DO NOT EDIT
$layout_defs['Thin_CyclePlans']['subpanel_setup']['thin_cycleplans_thin_cycleplantargets']['override_subpanel_name'] = 'Thin_CyclePlans_subpanel_thin_cycleplans_thin_cycleplantargets';
?>