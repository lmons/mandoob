<?php
 // created: 2017-03-03 12:34:08
$layout_defs["AOS_Products"]["subpanel_setup"]['aos_products_thin_sample_lot_1'] = array (
  'order' => 100,
  'module' => 'Thin_Sample_Lot',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_PRODUCTS_THIN_SAMPLE_LOT_1_FROM_THIN_SAMPLE_LOT_TITLE',
  'get_subpanel_data' => 'aos_products_thin_sample_lot_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
