<?php
// created: 2017-04-10 20:06:32
$dictionary["Account"]["fields"]["accounts_thin_cycleplantargets_1"] = array (
  'name' => 'accounts_thin_cycleplantargets_1',
  'type' => 'link',
  'relationship' => 'accounts_thin_cycleplantargets_1',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlanTargets',
  'bean_name' => 'Thin_CyclePlanTargets',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_THIN_CYCLEPLANTARGETS_1_FROM_THIN_CYCLEPLANTARGETS_TITLE',
);
