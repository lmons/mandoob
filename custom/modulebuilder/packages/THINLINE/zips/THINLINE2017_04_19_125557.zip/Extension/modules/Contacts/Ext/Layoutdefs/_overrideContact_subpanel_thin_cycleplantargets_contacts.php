<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['thin_cycleplantargets_contacts']['override_subpanel_name'] = 'Contact_subpanel_thin_cycleplantargets_contacts';
?>