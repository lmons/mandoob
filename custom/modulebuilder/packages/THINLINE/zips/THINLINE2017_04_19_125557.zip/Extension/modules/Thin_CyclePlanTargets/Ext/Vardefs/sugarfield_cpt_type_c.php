<?php
 // created: 2017-04-10 20:23:53
$dictionary['Thin_CyclePlanTargets']['fields']['cpt_type_c']['inline_edit']='1';
$dictionary['Thin_CyclePlanTargets']['fields']['cpt_type_c']['labelValue']='CPT TYPE';

 ?>