<?php
// created: 2017-02-21 19:55:18
$dictionary["AOS_Products"]["fields"]["aos_products_users_1"] = array (
  'name' => 'aos_products_users_1',
  'type' => 'link',
  'relationship' => 'aos_products_users_1',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_AOS_PRODUCTS_USERS_1_FROM_USERS_TITLE',
);
