<?php
 // created: 2016-12-30 13:00:06
$dictionary['Account']['fields']['country_c']['inline_edit']='1';
$dictionary['Account']['fields']['country_c']['labelValue']='Country';

 ?>