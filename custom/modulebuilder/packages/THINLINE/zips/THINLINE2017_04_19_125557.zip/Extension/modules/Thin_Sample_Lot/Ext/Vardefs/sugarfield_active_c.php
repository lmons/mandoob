<?php
 // created: 2017-03-03 12:49:48
$dictionary['Thin_Sample_Lot']['fields']['active_c']['inline_edit']='1';
$dictionary['Thin_Sample_Lot']['fields']['active_c']['labelValue']='Active';

 ?>