<?php
 // created: 2017-04-10 12:00:31
$dictionary['Thin_CyclePlans']['fields']['cp_type_c']['inline_edit']='1';
$dictionary['Thin_CyclePlans']['fields']['cp_type_c']['labelValue']='Cyle Plan type';

 ?>