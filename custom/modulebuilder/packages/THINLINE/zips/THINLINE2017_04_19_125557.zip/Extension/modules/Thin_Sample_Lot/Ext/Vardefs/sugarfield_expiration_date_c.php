<?php
 // created: 2017-03-03 12:49:04
$dictionary['Thin_Sample_Lot']['fields']['expiration_date_c']['inline_edit']='1';
$dictionary['Thin_Sample_Lot']['fields']['expiration_date_c']['options']='date_range_search_dom';
$dictionary['Thin_Sample_Lot']['fields']['expiration_date_c']['labelValue']='Expiration Date';
$dictionary['Thin_Sample_Lot']['fields']['expiration_date_c']['enable_range_search']='1';

 ?>