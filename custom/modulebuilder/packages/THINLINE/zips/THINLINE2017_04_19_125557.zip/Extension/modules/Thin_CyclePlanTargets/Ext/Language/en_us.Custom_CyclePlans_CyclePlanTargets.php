<?php

$mod_strings['LBL_BRICK'] = 'Brick';
$mod_strings['LBL_SPECIALTY'] = 'Specialty';
$mod_strings['LBL_SELECT_TARGET'] = 'Check Target';
$mod_strings['LBL_CHECK_TARGET']='Check Target';