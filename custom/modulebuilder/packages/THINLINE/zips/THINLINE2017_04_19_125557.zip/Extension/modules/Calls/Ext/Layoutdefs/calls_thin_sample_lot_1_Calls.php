<?php
 // created: 2017-03-10 19:21:24
$layout_defs["Calls"]["subpanel_setup"]['calls_thin_sample_lot_1'] = array (
  'order' => 100,
  'module' => 'Thin_Sample_Lot',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CALLS_THIN_SAMPLE_LOT_1_FROM_THIN_SAMPLE_LOT_TITLE',
  'get_subpanel_data' => 'calls_thin_sample_lot_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
