<?php 
 // created: 2017-04-19 12:55:30
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_EXPIRATION_DATE'] = 'Expiration Date';
$mod_strings['LBL_ACTIVE'] = 'Active';
$mod_strings['LBL_AOS_PRODUCTS_THIN_SAMPLE_LOT_1_FROM_AOS_PRODUCTS_TITLE'] = 'Sample';
$mod_strings['LBL_NAME'] = 'Lot';
$mod_strings['LBL_CALLS_THIN_SAMPLE_LOT_1_QUANTITY'] = 'Quantity';

?>
