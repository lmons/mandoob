<?php 
 // created: 2017-04-19 12:55:28
$mod_strings['LBL_THIN_CYCLEPLANS_THIN_CYCLEPLANTARGETS_FROM_THIN_CYCLEPLANTARGETS_TITLE'] = 'Cycle Plan Targets';
$mod_strings['LBL_PRODUCTIVE_FREQUENCY'] = 'Productive Frequency';
$mod_strings['LBL_CP_TYPE'] = 'Cyle Plan type';

?>
