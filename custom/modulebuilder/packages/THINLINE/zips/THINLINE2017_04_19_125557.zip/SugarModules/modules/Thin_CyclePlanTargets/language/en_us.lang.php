<?php 
 // created: 2017-04-19 12:55:27
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_CPT_TYPE'] = 'Type';

?>
