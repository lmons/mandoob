<?php
// created: 2017-03-13 11:41:43
$subpanel_layout['list_fields'] = array (
  'aos_products_thin_sample_lot_1_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'vname' => 'LBL_AOS_PRODUCTS_THIN_SAMPLE_LOT_1_FROM_AOS_PRODUCTS_TITLE',
    'id' => 'AOS_PRODUCTS_THIN_SAMPLE_LOT_1AOS_PRODUCTS_IDA',
    'width' => '30%',
    'default' => true,
    'widget_class' => 'SubPanelDetailViewLink',
    'target_module' => 'AOS_Products',
    'target_record_key' => 'aos_products_thin_sample_lot_1aos_products_ida',
  ),
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '30%',
    'default' => true,
  ),
    'quantity_non_db' =>
        array (
            'name' => 'quantity_non_db',
            'vname' => 'LBL_CALLS_THIN_SAMPLE_LOT_1_QUANTITY',
            'width' => '30%',
            'default' => true,
            'sortable' => false,
        ),
);