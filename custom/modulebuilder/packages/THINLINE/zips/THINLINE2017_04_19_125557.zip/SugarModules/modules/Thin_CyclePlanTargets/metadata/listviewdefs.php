<?php
$module_name = 'Thin_CyclePlanTargets';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'THIN_CYCLEPLANS_THIN_CYCLEPLANTARGETS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_THIN_CYCLEPLANS_THIN_CYCLEPLANTARGETS_FROM_THIN_CYCLEPLANS_TITLE',
    'id' => 'THIN_CYCLEPLANS_THIN_CYCLEPLANTARGETSTHIN_CYCLEPLANS_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'THIN_CYCLEPLANTARGETS_CONTACTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_THIN_CYCLEPLANTARGETS_CONTACTS_FROM_CONTACTS_TITLE',
    'id' => 'THIN_CYCLEPLANTARGETS_CONTACTSCONTACTS_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'CUSTOMER_TIER' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CUSTOMER_TIER',
    'width' => '10%',
    'default' => true,
  ),
  'CALL_FREQUENCY_TARGET' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CALL_FREQUENCY_TARGET',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
