<?php
 // created: 2017-01-02 16:58:17
$dictionary['Contact']['fields']['prc_number_c']['inline_edit']='1';
$dictionary['Contact']['fields']['prc_number_c']['labelValue']='PRC Number';

 ?>