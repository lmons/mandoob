<?php
 // created: 2016-12-30 17:09:39
$dictionary['Contact']['fields']['gender_c']['inline_edit']='1';
$dictionary['Contact']['fields']['gender_c']['labelValue']='Gender';

 ?>