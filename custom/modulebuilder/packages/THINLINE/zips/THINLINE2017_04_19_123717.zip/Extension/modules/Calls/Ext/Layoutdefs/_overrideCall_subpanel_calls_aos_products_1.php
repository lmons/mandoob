<?php
//auto-generated file DO NOT EDIT
$layout_defs['Calls']['subpanel_setup']['calls_aos_products_1']['override_subpanel_name'] = 'Call_subpanel_calls_aos_products_1';
?>