<?php
 // created: 2017-01-24 18:45:11
$dictionary['Call']['fields']['call_location_c']['inline_edit']='1';
$dictionary['Call']['fields']['call_location_c']['labelValue']='call location';

 ?>