<?php
 // created: 2017-02-17 13:14:20
$dictionary['Contact']['fields']['city_c']['inline_edit']='1';
$dictionary['Contact']['fields']['city_c']['labelValue']='City';

 ?>