<?php
 // created: 2016-12-30 17:18:26
$dictionary['Contact']['fields']['specialty_c']['inline_edit']='1';
$dictionary['Contact']['fields']['specialty_c']['labelValue']='Specialty';

 ?>