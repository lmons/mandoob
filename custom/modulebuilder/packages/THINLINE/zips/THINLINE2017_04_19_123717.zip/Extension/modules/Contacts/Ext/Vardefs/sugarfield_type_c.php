<?php
 // created: 2016-12-30 17:24:24
$dictionary['Contact']['fields']['type_c']['inline_edit']='1';
$dictionary['Contact']['fields']['type_c']['labelValue']='Type';

 ?>