<?php 
 // created: 2017-04-19 12:37:04
$mod_strings['LBL_GENDER'] = 'Gender';
$mod_strings['LBL_SPECIALTY'] = 'Specialty';
$mod_strings['LBL_TYPE'] = 'Type';
$mod_strings['LBL_PRC_NUMBER'] = 'PRC Number';
$mod_strings['LBL_BRICK'] = 'Brick';
$mod_strings['LBL_CITY'] = 'City';
$mod_strings['LBL_ADDRESS'] = 'Address';
$mod_strings['LBL_THIN_CYCLEPLANTARGETS_CONTACTS_FROM_THIN_CYCLEPLANTARGETS_TITLE'] = 'Cycle Plan Targets';

?>
