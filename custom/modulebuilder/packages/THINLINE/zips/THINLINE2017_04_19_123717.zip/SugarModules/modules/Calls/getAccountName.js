YAHOO.util.Event.onDOMReady(function () {
    if (document.getElementById('contactInAccountFree').value !== '1') {
        YAHOO.util.Event.addListener('parent_id', 'change', function () {
            if (document.getElementById('parent_type').value == 'Contacts') {
                console.log(this.value)
                YAHOO.util.Connect.asyncRequest('GET', 'API/ContactRelatedAccount.php?id_medecin=' + this.value, {
                    success: function (o) {
                        var jsonResponse = JSON.parse(o.responseText);
                        var x = document.getElementById('call_location_c');
                        x.innerHTML = '';
                        jsonResponse.entry_list.forEach(function (element, value) {
                            var option = document.createElement('option');
                            option.label = element.name_value_list.name.value;
                            option.text = element.name_value_list.name.value;
                            option.value = element.name_value_list.id.value;
                            x.add(option);
                            //x.add(options[i]=.labelelement.name_value_list.name.value);
                        });
                    },
                    failure: function (o) {
                    }
                });
            }
            else {
                YAHOO.util.Connect.asyncRequest('GET', 'API/AccountRelatedContacts.php?id_account=' + this.value, {
                    success: function (o) {
                        var jsonResponse = JSON.parse(o.responseText);
                        cols = 6;
                        colsIndex = 0;
                        counter = 0
                        rowByCols = Math.ceil(jsonResponse.entry_list.length / cols);
                        if (rowByCols !== 0) {
                            for (var i = 0; i < rowByCols; i++) {
                                $('#contactInAccount').append('<tr></tr>');
                                for (var j = colsIndex; j < colsIndex + cols; j++) {
                                    if (typeof(jsonResponse.entry_list[i + j]) != 'undefined') {
                                        $('#contactInAccount').find('tr').eq(i).append('<td><input type="checkbox" id="' + jsonResponse.entry_list[i + j].name_value_list.id.value + '" value="' + jsonResponse.entry_list[i + j].name_value_list.id.value + '" name="contacts-in-account[]">' + jsonResponse.entry_list[i + j].name_value_list.name.value + '</td>');
                                        $('#contactInAccount').find('tr').eq(i).find('td').eq(j).attr('data-row', i).attr('data-col', j);
                                        counter++;
                                    }

                                }
                                colsIndex = counter;
                            }
                        }
                    },
                    failure: function (o) {
                    }
                });
            }
        });
    }
    var event = new Event('change');
    document.getElementById('parent_id').dispatchEvent(event);


});
