$( document ).ready(function() {
    $('#parent_type').find('option[value!="Accounts"][value!="Contacts"]').remove()
    $('#direction').remove()
    $('#status').attr('disabled', 'disabled');
});