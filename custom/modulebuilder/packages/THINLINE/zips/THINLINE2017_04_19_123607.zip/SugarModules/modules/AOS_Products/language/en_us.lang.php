<?php 
 // created: 2017-04-19 12:36:04
$mod_strings['LBL_CALLS_THIN_SAMPLE_LOT_1_PRIORITY'] = 'Priority';

?>
