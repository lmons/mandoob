<?php 
$app_list_strings['product_type_dom'] = array (
  'Detail' => 'Detail',
  'Sample' => 'Sample',
);