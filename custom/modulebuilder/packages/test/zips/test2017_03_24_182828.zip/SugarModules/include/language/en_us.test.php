<?php 
$app_list_strings['call_location_list'] = array (
);