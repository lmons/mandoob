<?php 
 // created: 2017-03-24 18:28:15
$mod_strings['LBL_CALL_LOCATION'] = 'Call Location';
$mod_strings['LBL_CALL_LOCATION_NAME'] = 'Call Location';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Product';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Products';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Samples';
$mod_strings['LBL_CALLS_THIN_SAMPLE_LOT_1_FROM_THIN_SAMPLE_LOT_TITLE'] = 'Sample Lot';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Samples';
$mod_strings['LBL_CALLS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE'] = 'Products';

?>
