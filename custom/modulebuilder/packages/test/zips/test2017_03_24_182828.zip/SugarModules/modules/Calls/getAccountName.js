YAHOO.util.Event.onDOMReady(function(){
    YAHOO.util.Event.addListener('parent_id','change',function(){
        YAHOO.util.Connect.asyncRequest('GET','API/ContactRelatedAccount.php?id_medecin='+this.value,{
            success:function(o){
                var jsonResponse=JSON.parse(o.responseText);
                var x = document.getElementById('call_location_c');
                x.innerHTML = '';
                jsonResponse.entry_list.forEach(function(element,value) {
                    var option=document.createElement('option');
                    option.label=element.name_value_list.name.value;
                    option.text=element.name_value_list.name.value;
                    option.value=element.name_value_list.id.value;
                    x.add(option);
                    //x.add(options[i]=.labelelement.name_value_list.name.value);
                });
            },
            failure:function(o){
            }
        });

    });
    var event = new Event('change');
    document.getElementById('parent_id').dispatchEvent(event);
});
