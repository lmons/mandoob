<?php
 // created: 2017-03-06 11:15:30
$layout_defs["AOS_Products"]["subpanel_setup"]['aos_products_aos_products_1aos_products_ida'] = array (
  'order' => 100,
  'module' => 'AOS_Products',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_PRODUCTS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_R_TITLE',
  'get_subpanel_data' => 'aos_products_aos_products_1aos_products_ida',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
